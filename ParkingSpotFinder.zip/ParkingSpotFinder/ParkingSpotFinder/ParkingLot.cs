﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParkingSpotFinder
{
    public class ParkingLot
    {
        private List<IParkingSpot> listParkingSpot = new List<IParkingSpot>();
        public ParkingLot()
        {
            Random random = new Random();
            //generate the parking spots
            for (int i = 1; i <= 10; i++)
                 listParkingSpot.Add(new SmallParkingSpot("HB" + i.ToString(), random.Next(0, 2) == 0));
            
            for (int i = 1; i <= 5; i++)
                listParkingSpot.Add(new MediumParkingSpot("SD" + i.ToString(), random.Next(0, 2) == 0));

            for (int i = 1; i <= 3; i++)
                listParkingSpot.Add(new LargeParkingSpot("MT" + i.ToString(), random.Next(0, 2) == 0));
        }

        public void DisplayAllSpots()
        {
            Console.WriteLine("All Parking Spots...\n");
            foreach (var spot in listParkingSpot)
            {
                Console.WriteLine($"Number: {spot.Number}\tSize: {spot.Size}\tIsOccupied: {spot.IsOccupied}");
            }
        }

        public IParkingSpot GetSpot(string vehicleType)
        {
            VehicleFactory vehicleFactory = new VehicleFactory();
            var vehicle = vehicleFactory.GetVehicle(vehicleType);

            var availableSpot = GetSpot(vehicle.Size);
            return availableSpot;
        }

        public string Park(Vehicle vehicle)
        {
            var spot = GetSpot(vehicle.Size);
            if(spot != null)
                spot.Occupy(vehicle);
           
            return spot.Number;
        }

        private IParkingSpot GetSpot(VehicleSize vehicleSize)
        {
            var availableSpot = listParkingSpot.OrderBy(x => x.Size)
                                             .FirstOrDefault(x => x.IsOccupied == false && x.Size >= vehicleSize);
            return availableSpot;
        }
    }
}
