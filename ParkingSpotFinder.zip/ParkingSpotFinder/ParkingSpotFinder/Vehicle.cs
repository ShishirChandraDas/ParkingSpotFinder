﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParkingSpotFinder
{
    public abstract class Vehicle
    {
        internal VehicleSize Size;
        internal string Number;
    }

    public class HatchBackCar : Vehicle
    {
        public HatchBackCar()
        {
            Size = VehicleSize.Small;
        }
    }

    public class SedanCar : Vehicle
    {
        public SedanCar()
        {
            Size = VehicleSize.Medium;
        }
    }

    public class MiniTruck : Vehicle
    {
        public MiniTruck()
        {
            Size = VehicleSize.Large;
        }
    }
}
