﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParkingSpotFinder
{
    class Program
    {
        static void Main(string[] args)
        {
            ParkingLot spotFinder = new ParkingLot();
            Console.WriteLine("Enter vehicle type to be parked...");
            string vehicleType = Console.ReadLine();

            spotFinder.DisplayAllSpots();
            var spot = spotFinder.GetSpot(vehicleType);
            if (spot != null)
            {
                Console.WriteLine($"Available spot : {spot.Number} \nBase Price :{spot.BasePrice}\n");
            }
            else
            {
                Console.WriteLine($"Parking Full. No spot available!");
            }
            
            Vehicle vehicle = new HatchBackCar() { Number = "MH12XXXXXX" };

            if (spot != null)
            {
                string number = spotFinder.Park(vehicle);
            }
            spotFinder.DisplayAllSpots();

            Console.ReadKey();
        }
    }
}
