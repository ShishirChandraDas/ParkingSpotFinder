﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParkingSpotFinder
{
    public interface IParkingSpot
    {
        string Number { get; set; }
        VehicleSize Size { get; set; }
        bool IsOccupied { get; set; }
        Vehicle Vehicle { get; set; }
        double BasePrice { get; set; }

        void Occupy(Vehicle vehicle);
        void Release();
        void CalculatePrice();
    }

    public class SmallParkingSpot : IParkingSpot
    {
        public string Number { get; set; }
        public VehicleSize Size { get; set; }
        public bool IsOccupied { get; set; }
        public Vehicle Vehicle { get; set; }
        public double BasePrice { get; set; }

        public SmallParkingSpot(string number, bool isOccupied)
        {
            Number = number;
            Size = VehicleSize.Small;
            IsOccupied = isOccupied;
            BasePrice = 50.00;
        }

        public void Occupy(Vehicle vehicle)
        {
            Vehicle = vehicle;
            IsOccupied = true;
        }

        public void Release()
        {
            Vehicle = null;
            IsOccupied = false;
        }

        public void CalculatePrice()
        {
            throw new NotImplementedException();
        }
    }

    public class MediumParkingSpot : IParkingSpot
    {
        public string Number { get; set; }
        public VehicleSize Size { get; set; }
        public bool IsOccupied { get; set; }
        public Vehicle Vehicle { get; set; }
        public double BasePrice { get; set; }

        public MediumParkingSpot(string number, bool isOccupied)
        {
            Number = number;
            Size = VehicleSize.Medium;
            IsOccupied = isOccupied;
            BasePrice = 80.00;
        }

        public void Occupy(Vehicle vehicle)
        {
            Vehicle = vehicle;
            IsOccupied = true;
        }

        public void Release()
        {
            Vehicle = null;
            IsOccupied = false;
        }

        public void CalculatePrice()
        {
            throw new NotImplementedException();
        }
    }

    public class LargeParkingSpot : IParkingSpot
    {
        public string Number { get; set; }
        public VehicleSize Size { get; set; }
        public bool IsOccupied { get; set; }
        public Vehicle Vehicle { get; set; }
        public double BasePrice { get; set; }

        public LargeParkingSpot(string number, bool isOccupied)
        {
            Number = number;
            Size = VehicleSize.Large;
            IsOccupied = isOccupied;
            BasePrice = 100.00;
        }

        public void Occupy(Vehicle vehicle)
        {
            Vehicle = vehicle;
            IsOccupied = true;
        }

        public void Release()
        {
            Vehicle = null;
            IsOccupied = false;
        }

        public void CalculatePrice()
        {
            throw new NotImplementedException();
        }
    }
}
   