﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParkingSpotFinder
{
    public class VehicleFactory 
    {
        public Vehicle GetVehicle(string vehicleType)
        {
            switch(vehicleType.ToUpper())
            {
                case "HATCHBACK":
                    return new HatchBackCar();
                case "SEDAN":
                    return new SedanCar();
                case "MINITRUCK":
                    return new MiniTruck();
                default: throw new Exception("Vehicle type not supported!");
            }
        }
    }
}
